const apiURL = "http://localhost:3000/usuarios/1"; // Exemplo para usuário com ID 1

async function salvarUsuario() {
  const usuario = {
    nome: document.getElementById("nome").value,
    perfil: document.getElementById("perfil").value,
    dados: {
      email: document.getElementById("email").value,
      data_nascimento: document.getElementById("data_nascimento").value || null
    },
    localizacao: "",
    bio: document.getElementById("bio").value || null
  };

  await fetch(apiURL, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(usuario)
  });

  alert("Usuário atualizado!");
}

async function visualizarUsuario() {
  const res = await fetch(apiURL);
  const user = await res.json();

  document.getElementById("usuarioDetalhes").innerHTML = `
    <h3>Usuário Atual:</h3>
    <p><strong>Nome:</strong> ${user.nome}</p>
    <p><strong>Email:</strong> ${user.dados.email}</p>
    <p><strong>Nascimento:</strong> ${user.dados.data_nascimento}</p>
    <p><strong>Bio:</strong> ${user.bio}</p>
    <p><img src="${user.perfil}" width="100" /></p>
  `;
}
